% arma.m - Mayne-Firoozan ARMA modeling method
%
% Usage: [a,b,sigma2] = arma(y,p,q,M,iter)
%        [a,b,sigma2] = arma(y,p,q,M)      (equivalent to iter=2)
%
% y = complex-valued data signal (entered as row or column), y must have zero mean
% p = order of denominator filter A(z), p>0
% q = order of numerator filter B(z),   q>0
% M = order of preliminary AR filter,   M>>max(p,q)
% iter = number of refinement iterations (Mayne-Firoozan has iter=2)
%
% a = denominator filter, a = [1; a1; a2; ...; ap]
% b = numerator filter,   b = [1; b1; b2; ...; bq]
% sigma2 = variance of input white noise
%
% notes: initial AR(M) model estimation can be done by any method, 
%        for example, using Burg, a = lpf(burg(y,M));
%
%        a variant of the algorithm is to use 
%           c = -[V1,-W1]\v0;        at the first iteration
%           c = -[V1,-W1]\(v0-w0);   at subsequent iterations
%
%        V=B\Y is equivalent to filtering and forming the datamatrix:
%        v = filter(1,b,y); V = datamat(v,p,'pre');
%
%        method fails if B(z) is non-minimum phase
%
% References:
%   J. Durbin, The Fitting of Time Series Models, 
%       Rev. Int. Stat. Inst., vol.28, 233 (1961).
%   D. Q. Mayne and F. Firoozan, Linear Identification of ARMA Processes,
%       Automatica, vol.18, 461 (1982).
%   E. J. Hannan and J. Rissanen, Recursive Estimation of Mixed 
%       Autoregressive-Moving Average Order, Biometrika, vol.69, 81 (1982).

% S. J. Orfanidis - 2004
% ECE Department
% Rutgers University
% Piscataway, NJ 08854
% email: orfanidi@ece.rutgers.edu

function [a,b,sigma2] = arma(y,p,q,M,iter)

if nargin==0, help arma; return; end
if nargin==4, iter=2; end

y = y(:); 
N = length(y);

a = lpf(yw(y,M));           % could be replaced by Burg, a = lpf(burg(y,M));
e = filter(a,1,y);          % estimated innovations sequence, e has length N

Y = datamat(y,p,'pre');     % Y is Nx(p+1)
E = datamat(e,q,'pre');     % E is Nx(q+1)

B = eye(N,N);                                   % initially, B(z) = 1

for i=1:iter,                                   % initial and refinement iterations

   V = B\Y;  v0 = V(:,1);  V1 = V(:,2:end);     % inverse filtering by B(z)
   W = B\E;  w0 = W(:,1);  W1 = W(:,2:end);     % note V=[v0,V1], W=[w0,W1]

   c = -[V1,-W1]\(v0-w0);                       % least-squares solution of V*a=E*b
   a = [1; c(1:p)];                             % extract a,b from c
   b = [1; c(p+1:p+q)];      

   gamma = lpg(bkwlev(b));                      % minimum-phase test of B(z)
   if max(abs(gamma))>=1, disp('B(z) is not minimum-phase'); return; end               

   B = datamat(b,N-1); B = B(1:N,:);            % B = NxN convolution matrix of b

end

% -------------------- sigma2  computation ---------------

R = max(abs(roots(a)));

if R>=1, disp('model is unstable'); return; end

Neff = floor(log(0.001)/log(R));          % 60-dB time constant 

h = filter(b,a,[1,zeros(1,Neff)]); 

sigma2 = norm(y).^2 /N / norm(h)^2;


