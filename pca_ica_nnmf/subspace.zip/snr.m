% snr.m - magnitude to SNR in dB, and conversely
%
% Usage: B = snr(A, type)
%        B = snr(A)       (equivalent to type=1)
%
% A    = vector of magnitudes in absolute units (or, SNRs in dB if type=-1)
% type = 1, -1 for magnitude to dB, or, dB to magnitude
%
% B = vector of SNRs in dB (or, magnitudes if type=-1)
%
% notes: type= 1, B = 10*log10(A^2/2)         (magnitude to dB)
%        type=-1, B = sqrt(2) * 10^(A/20)     (dB to magnitude)
%
%        noise variance is assumed to be sigmav^2=1,2 for real or complex sinusoids
%
% see also SINES, FISHER

% S. J. Orfanidis - 1999
% ECE Department
% Rutgers University
% Piscataway, NJ 08854
% email: orfanidi@ece.rutgers.edu

function B = snr(A,type)

if nargin==0, help snr; return;end
if nargin==1, type=1; end

if type==1,
    B = 10 * log10(A.^2/2);                 % magnitudes to SNRs in dB
else
    B = sqrt(2) * 10.^(A/20);               % SNRs in dB to magnitudes  
end

