% mpencil.m - matrix-pencil method of extracting sinusoids in noise
%
% Usage: [z,A] = mpencil(y,r,M)
%
% y = length-N signal 
% r = number of sinusoids
% M = embedding dimension, r <= M <= N-r, typically, M = N/6, N/4, N/3 (opt)
%
% z = length-r vector of complex sinusoid zeros, z = exp(-a + j*w)
% A = length-r vector of complex sinusoid amplitudes, A = abs(A).*exp(j*phi)
%
% notes: Y. Hua and T. K. Sarkar, "Matrix Pencil Method for Estimating Parameters of
%        Exponentially Dampled/Undamped Sinusoids in Noise", 
%        IEEE Trans. Acoust. Speech Signal Process., ASSP-38, 814 (1990)
%
%        Form Y = datamat(y,M,1) = (N-M)x(M+1) covariance-type data matrix, then define
%        Y1 = Y(:,1:M) = first M columns of Y, Y0 = Y(:,2:M+1) = last M columns,  
%        and solve the matrix pencil problem (Y1-z*Y0) after replacing Y0 by its
%        rank-r SVD approximation Y0=U*S*V' and reducing the problem to size rxr,  
%        that is, U'*(Y1-z*Y0)*V = U'*Y1*V - z*S; amplitudes A are obtained from
%        the LS solution of y = St*A, where St = order-(N-1) steering matrix
%
%        y can be replaced by its iterated rank-r SVD-enhanced version: 
%           for k=1:K, 
%               Y = toepl(sigsub(Y,r));     (rank-r approximation and toeplitz-ize)
%           end
%           ye = datasig(Y,1);              (extract enhanced signal)
%
%        M = N/3 is optimum (for single sinusoid) with var(w1)/CRB(w1) = 1.125

% S. J. Orfanidis - 1999
% ECE Department
% Rutgers University
% Piscataway, NJ 08854
% email: orfanidi@ece.rutgers.edu

function [z,A] = mpencil(y,r,M)

if nargin==0, help mpencil; return; end

N = length(y); 
y = y(:);

Y = datamat(y,M,1);                     % order-M covariance-type data matrix                      

[U,S,V] = svd(Y(:,2:M+1),0);            % Y0 = Y(:,2:M+1) = USV'
S = S(1:r,1:r);                           
U = U(:,1:r);                           % rank-r approximation of Y0 is Yr = Ur*Sr*Vr'
V = V(:,1:r);                               
                                        % the r sinusoid zeros are the r eigenvalues 
z = eig(S \ U' * Y(:,1:M) * V);         % of Sr\Ur'*Y1*Vr, where Y1 = Y(:,1:M)

A = steermat(N-1,z) \ y;                % LS solution of steermat(N-1,z)*A = y




