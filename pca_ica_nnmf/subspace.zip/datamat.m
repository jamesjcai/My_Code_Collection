% datamat.m - convolution data matrix of a signal vector 
%
% Usage: Y = datamat(y,M,type)
%        Y = datamat(y,M)      (default type=0)
%
% y    = length-N vector of time samples (row or column)
% M    = linear prediction order or number of delay shifts, (must have M>=1)
% type = 0,1,2 for autocorrelation, covariance, or forward/backward method
% type = 3 for the prewindowed method 
% type can also be entered as a string: 'aut', 'cov', 'fb', 'pre'
% 
% Y = data matrix whose M+1 columns are obtained from the delayed versions of y
%
% notes: For example, if y = [y0,y1,y2,y3,y4,y5] and M=2, the matrices Y are:
%             
%           [ y0   0   0     [ y2  y1  y0      [ y2   y1   y0
%             y1  y0   0       y3  y2  y1        y3   y2   y1
%             y2  y1  y0       y4  y3  y2        y4   y3   y2
%             y3  y2  y1       y5  y4  y3 ]      y5   y4   y3   
%             y4  y3  y2                         y0*  y1*  y2*
%             y5  y4  y3                         y1*  y2*  y3*
%             0   y5  y4                         y2*  y3*  y4*
%             0   0   y5 ]                       y3*  y4*  y5* ]                    
%
%        for type=0,1, Y is Toeplitz, for type=2, it is Toeplitz over Hankel
%        
%        typical choices: M = N/6, N/3, N/2, 3N/4, and M=N-r/2 (Kumaresan-Prony)
%
% see also DATASIG for extracting y from Y

% S. J. Orfanidis - 1999
% ECE Department
% Rutgers University
% Piscataway, NJ 08854
% email: orfanidi@ece.rutgers.edu9

function Y = datamat(y,M,type)

if nargin==0, help datamat; return; end
if nargin==2, type=0; end

N = length(y);

Y = convmtx(y(:),M+1);               % convolution matrix of y with M+1 columns

% if convmtx is not available, use the following construction:
% Y = zeros(N+M,M+1);  for i=0:M, Y(i+1:i+N, i+1) = y(:); end

switch type
  case {0,'aut','a'}
                                            % no action
  case {1,'cov','c'}
    Y = Y(M+1:N,:);                         % steady part of Y - covariance method

  case {2,'fb','f'}
    Y = [Y(M+1:N,:); fliplr(conj(Y(M+1:N,:)))];       % forward-backward method

  case {3,'pre','p'}
   Y = Y(1:N,:);                            % prewindowed method

  otherwise
     disp('Unknown method.')
end






