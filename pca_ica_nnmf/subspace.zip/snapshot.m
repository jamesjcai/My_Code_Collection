% snapshot.m - generate data matrix of snapshots for array problems
%
% Usage: Y = snapshot(N,M,k,P,seed)
%
% N    = number of snapshots
% M+1  = number of array elements
% k    = length-r vector of wavenumbers of incident plane waves
% P    = rxr power matrix of incident waves (not necessarily of full rank)
% seed = initialization seed for random number generator
%
% Y = Nx(M+1) data matrix of snapshots
%
% notes: generates N snapshots of the form y = conj(S)*A + v, where y is an 
%        (M+1)-dimensional column vector, S is the (M+1)xr steering matrix 
%        towards the r plane waves, A is an rx1 random amplitude with autocorrelation
%        matrix P, and v is zero-mean, unit-variance complex Gaussian noise. 
%        The N snapshots are arranged as the rows of Y.
%
%        desired SNRs are adjusted through P: SNR = 10*log10(diag(P)/sigmav^2)
%        angles of arrival: k(i) = (2*pi*d/lambda)*sin(theta(i)), i=1,...,r  
%
%        method: [U,D] = eig(P)
%                generate V = Nx(M+1) unit-variance incoherent noise data matrix
%                generate C = Nxr unit-variance independent amplitude data matrix
%                A = B*U' = C*sqrt(D)*U'
%                Y = A*S' + V
%        check:  A'*A = U*(B'*B)*U' = U*sqrt(D)*(C'*C)*sqrt(D)*U' = U*D*U' = P
%                Y'*Y = (A*S')'*(A*S) + V'*V = S*(A'*A)*S' + V'*V = S*P*S' + I

% S. J. Orfanidis - 1999
% ECE Department
% Rutgers University
% Piscataway, NJ 08854
% email: orfanidi@ece.rutgers.edu

function Y = snapshot(N,M,k,P,seed)

if nargin==0, help snapshot; return; end

r = length(k);                                      % number of plane waves

[U,D] = eig(P);                                     % diagonalize P
D1 = sqrt(D);                                       % stdev of signal amplitudes

S = steermat(M,exp(j*k));                           % construct steering matrix

randn('state', seed);                               % seed initialization

V = (randn(N,M+1) + j*randn(N,M+1))/sqrt(2);        % unit-variance noise data matrix
C = (randn(N,r) + j*randn(N,r))/sqrt(2);            % unit-variance amplitudes

B = C * D1;                                         % rescale amplitude variances
A = B * U';                                         % Nxr amplitude data matrix

Y = A * S' + V;





