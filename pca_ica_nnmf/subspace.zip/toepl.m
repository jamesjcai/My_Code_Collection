% toepl.m - Toeplitz, Hankel, or Toeplitz/Hankel approximation of a data matrix
%
% Usage: Z = toepl(Y,type)
%        Z = toepl(Y)      (equivalent to type=0)
%
% Y    = data matrix
% type = 0,1,2, for Toeplitz, Hankel, or Toeplitz over Hankel
%
% Z = Toeplitz, Hankel, or Toeplitz/Hankel approximation of Y
%
% notes: type=0: each diagonal of Y is replaced by its average
%        type=1: each anti-diagonal of Y is replaced by its average
%        type=2: Y must have an even number of rows, then,
%                Y1 = upper-half of Y, T1 = toepl(Y1),
%                Y2 = lower-half of Y, T2 = toepl(conj(fliplr(Y2)))
%                T = (T1 + T2)/2, H = conj(fliplr(T)),
%                Z = [T; H]
%
%        in all cases, Z is the closest such matrix to Y in the Frobenius norm
%
% example: Y = [10 10 10   Z0 = [20 15 10   Z1 = [10 15 20   Z2 = [35 30 25
%               20 20 20         30 20 15         15 20 30         40 35 30
%               30 30 30         40 30 20         20 30 40         45 40 35
%               40 40 40         50 40 30         30 40 50         25 30 35
%               50 50 50         55 50 40         40 50 55         30 35 40
%               60 60 60]        60 55 50]        50 55 60]        35 40 45]

% S. J. Orfanidis - 1999
% ECE Department
% Rutgers University
% Piscataway, NJ 08854
% email: orfanidi@ece.rutgers.edu

function Z = toepl(Y,type)

if nargin==0, help toepl; return; end
if nargin==1, type=0; end

[N,K] = size(Y);

if type==0,
    c = [];
    r = [];

    for k=0:N-1,
        c = [c; mean(diag(Y,-k))];      % construct first column of Z
    end

    for k=0:K-1,
        r = [r, mean(diag(Y,k))];       % construct first row of Z
    end

    Z = toeplitz(c,r);                  % c wins diagonal conflict
end

if type==1,
    Z = fliplr(toepl(fliplr(Y)));       % also equal to flipud(toepl(flipud(Y)))
end

if type==2,
    if rem(N,2)~=0, fprintf('Y must have an even number of rows\n'); return; end  
    L = N/2;   

    T = (toepl(Y(1:L,:),0) + fliplr(conj(toepl(Y(L+1:end,:),1)))) / 2;

    Z = [T; fliplr(conj(T))];
end

    
