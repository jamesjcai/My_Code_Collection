% S. J. Orfanidis - 1999
% ECE Department
% Rutgers University
% Piscataway, NJ 08854
%
% orfanidi@ece.rutgers.edu
%
% Subspace Methods and SVD Signal Enhancement
% ---------------------------------------------
% ARMA      Mayne-Firoozan ARMA modeling method
% CCA       perform canonical correlation analysis on two data matrices
% CCACOV    perform CCA on a covariance matrix
% DATAMAT   construct data matrix from data signal
% DATASIG   extract data signal from data matrix
% LPLS      construct least-squares linear prediction filter from data matrix
% MA        MA modeling by Durbin's method
% MPENCIL   matrix-pencil method of extracting sinusoids in noise
% SETRANK   set the rank of a diagonal matrix of singular values
% SIGSUB    construct the signal and noise subspaces of a data matrix
% SINES     generate sum of real or complex decaying sinusoids in noise
% SNAPSHOT  generate data matrix of snapshots for array problems
% SNR       magnitudes in absolute units to SNRs in dB, and conversely
% STEERMAT  steering matrix towards multiple sinusoids/plane-waves
% TOEPL     Toeplitz, Hankel, or Toeplitz/Hankel approximation of a data matrix

% DTFT      computes the DTFT of a signal x at a frequency vector w
% ZMEAN     zero mean of each column of a data matrix (or row vector)
% LOADFILE  load a data file ignoring any text lines

