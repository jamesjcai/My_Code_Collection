% loadfile.m - load data file ignoring any text lines
%
% Usage: [Y,T] = loadfile(filename)
%
% filename = file pathname in single quotes, e.g., 'path/file.dat'
%
% Y = data matrix (NxM)
% T = string matrix of text lines in file
% 
% notes: all data lines must contain the same number of data, say M numbers per line,
%        a data line may have text to the right of the M data, but not to the left,
%        a text line may not begin with a number,
%        there can be text lines between data lines,
%        blank lines are ignored,
%        all text lines at beginning, end, and between data lines, are collected in T
%
% example: file:
%                Description of Data     line 1
%                -------------------     line 2
%                1 2 3 4                 line 3
%                5 6 7 8                 line 4
%                                        line 5
%                more text               line 6
%                                        line 7
%                2 4 6 8                 line 8
%                end of data             line 9
%
%            Y = [1 2 3 4        T = [Description of Data    line 1
%                 5 6 7 8             -------------------    line 2
%                 2 4 6 8],           more text              line 6
%                                     end of data            line 9]
%
% S. J. Orfanidis - OSP Toolbox - 1998

function [Y,T] = loadfile(filename)

if nargin==0, help loadfile; return; end

fp = fopen(filename);

if fp==-1, fprintf('%s does not exist\n', filename); return; end

Y = [];                                         % data matrix
T = [];                                         % text lines

while feof(fp) == 0,                            % while not at eof
    line = fgetl(fp);                           % read next line
    [y, M] = sscanf(line, '%f', [1,inf]);       % read M-dimensional row of data
    if M ~= 0,                                  % if the row contains data,         
       Y = [Y; y];                              % then, append it to Y
    else                                        % else, if the row contains text,
       T = strvcat(T, line);                    % then, append it to T        
    end
end

fclose(fp);


