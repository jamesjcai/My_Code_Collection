% lpls.m - construct least-squares linear prediction filter from data matrix
%
% Usage: [a,E] = lpls(Y)
%
% Y = Lx(M+1) data matrix with L > M+1
%
% a = order-M linear prediction filter, a = [a0,a1,a2,...,aM], a0 = 1
% E = order-M mean-square prediction error, that is, E = e'*e / L, where e = Y*a
%
% notes: Solves the overdetermined system Y*a = 0, under the constraint a0 = 1.
%        Separating first column of Y=[y0, Y1], and writing a=[1; a1], we have
%        the equivalent system y0 + Y1*a1 = 0, with solution a1 = -pinv(Y1)*y0
%        which corresponds to the minimum-norm least-squares solution
%
%        Implementation of autocorrelation, covariance, and forward/backward methods
%        (E is normalized by L=N+M, N-M, 2*(N-M) for type=0,1,2, where N=length(y)):
%
%           [a,E] = lpls(datamat(y,M,0)) = autocorrelation or Yule-Walker method
%           [a,E] = lpls(datamat(y,M,1)) = covariance method
%           [a,E] = lpls(datamat(y,M,2)) = modified covariance or forward/backward method
%
%        Y can also be replaced by its SVD-enhanced version obtained by 
%        toeplitzizing the rank-r version of the original Y, that is,
%        Y = toepl(sigsub(Y,r), type), and repeating this process a few more times,
%        (use type=0 if Y is toeplitz, and type=2 if Y is toeplitz/hankel)
%
%        see also YW, BURG, and MATLAB's ARBURG, ARYULE, ARCOV, ARMCOV
%        equivalence to YW: a = lpls(datamat(y,M,0)) = lpf(yw(y,M))
%

% S. J. Orfanidis - 1999
% ECE Department
% Rutgers University
% Piscataway, NJ 08854
% email: orfanidi@ece.rutgers.edu

function [a,E] = lpls(Y)

if nargin==0, help lpls; return; end

a = [1; -pinv(Y(:,2:end))*Y(:,1)];
% a = [1; -Y(:,2:end) \ Y(:,1)];

E = norm(Y*a)^2 / size(Y,1);            % E = e'*e, e = Y*a


