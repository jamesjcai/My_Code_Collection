% sigsub.m - construct reduced-rank signal subspace of a data matrix  
%
% Usage: [Ys,Yn,S] = sigsub(Y,r)
%
% Y = Nx(M+1) data matrix (with N > M+1)
% r = rank of the signal subspace (must have r <= M)
%
% Ys = Nx(M+1) data matrix of signal subspace
% Yn = Nx(M+1) data matrix of noise subspace
% S  = all M+1 singular values of Y
%
% notes: given an Nx(M+1) data matrix Y, it constructs the rank-r signal subspace Ys
%        and rank-(M+1-r) noise subspace Yn, such that Y = Ys + Yn, and Ys'*Yn = 0
%
%        for sinusoids in noise, r = number of complex sinusoids
%        for angle-of-arrival estimation, r = number of plane waves
%
% see also SETRANK

% S. J. Orfanidis - 1999
% ECE Department
% Rutgers University
% Piscataway, NJ 08854
% email: orfanidi@ece.rutgers.edu

function [Ys,Yn,S] = sigsub(Y,r)

if nargin==0, help sigsub; return; end

[U,S,V] = svd(Y,0);         % economy SVD, U, S, V are Nx(M+1), (M+1)x(M+1), (M+1)x(M+1)

Ys = U * setrank(S,r) * V';

Yn = Y - Ys;






