% steermat.m - construct steering matrix of multiple sinusoids/plane-waves 
%
% Usage: S = steermat(M,z)
%
% M = maximum lag, or, filter order (M >= r)
% z = length-r vector of sinusoid zeros [z(1),...,z(r)]
%
% S = (M+1)xr steering matrix
%
% notes: i-th sinusoid has z(i) = exp(-a(i)) * exp(j*w(i)), i=1,...,r, 
%
%        i-th column of S is the steering vector towards i-th sinusoid, that is,
%        z(i)^m = exp(-a(i)*m) * exp(j*w(i)*m), m=0,1,...,M
%
%        for plane-waves, w(i) are the normalized wavenumbers k(i), related to 
%        the angles of arrival theta(i) by k(i) = (2*pi*d/lambda)*sin(theta(i))
%
%        z can be entered as a row or column vector

% S. J. Orfanidis - 1999
% ECE Department
% Rutgers University
% Piscataway, NJ 08854
% email: orfanidi@ece.rutgers.edu

function S = steermat(M,z)

if nargin==0, help steermat; return; end

r = length(z);

m = (0:M)';

S = [];

for i=1:r,                  % build the columns of S
   S = [S, z(i).^m];         
end







