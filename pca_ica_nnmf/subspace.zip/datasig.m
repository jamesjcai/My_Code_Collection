% datasig.m - extract data signal from a Toeplitz or Toeplitz/Hankel data matrix
%
% Usage: y = datasig(Y,type)
%        y = datasig(Y)      (default type=0)
%
% Y    = convolution data matrix (with M+1 columns)
% type = 0,1,2, for autocorrelation, covariance, or forward/backward method
%
% y = length-N data signal that makes up Y 
%
% notes: type=0,  Y is (N+M)x(M+1),      y is obtained from the first column of Y
%        type=1,  Y is (N-M)x(M+1),      y is obtained from upper-left corner of Y
%        type=2,  Y is (2*(N-M))x(M+1),  y is obtained from upper-left corner of Y
%
%        inverse operations: Y = datamat(y,M,type) <==> y = datasig(Y,type) 
%             
%        SVD-enhancement procedure:
%           Y  = datamat(y,M,type) = construct data matrix of a signal y 
%           Ys = sigsub(Y,r)       = construct rank-r signal subspace of Y
%           Ye = toepl(Ys,type)    = make it Toeplitz or Toeplitz/Hankel
%           ye = datasig(Ye,type)  = extract SVD-enhanced signal 
%           (optionally, set y=ye and repeat a few more times)
%
% see also DATAMAT and TOEPL for the structuring conventions of Y
       
% S. J. Orfanidis - 1999
% ECE Department
% Rutgers University
% Piscataway, NJ 08854
% email: orfanidi@ece.rutgers.edu

function y = datasig(Y,type)

if nargin==0, help datasig; return; end
if nargin==1, type=0; end

[L,K]=size(Y);

if type==0, 
    y = Y(1:L-K+1,1);
end

if type==1,
    y = [flip(Y(1,:).'); Y(2:end,1)];
end

if type==2,
    y = datasig(Y(1:L/2,:),1);                 % Toeplitz half of Y, L is even
end

    







