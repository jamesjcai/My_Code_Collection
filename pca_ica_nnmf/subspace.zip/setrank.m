% setrank.m - reduce the rank of a diagonal matrix of singular values  
%
% Usage: Sr = setrank(S,r)
%
% S = (M+1)x(M+1) diagonal matrix of singular values (of an Nx(M+1) data matrix Y)
% r = dimension of signal subspace (must be r <= M)
%
% Sr = diagonal matrix of first r singular values of S followed by M+1-r zeros 
%
% notes: S  = diag([s(1), ..., s(r), s(r+1), ..., s(M+1)])
%        Sr = diag([s(1), ..., s(r), 0, 0,   ..., 0   ])
%
%        The rank-r data matrix of the signal subspace can be constructed as:
%
%           [U,S,V] = svd(Y,0)
%           Sr = setrank(S,r)
%           Yr = U*Sr*V'
%
% see also SIGSUB

% S. J. Orfanidis - 1999
% ECE Department
% Rutgers University
% Piscataway, NJ 08854
% email: orfanidi@ece.rutgers.edu

function Sr = setrank(S,r)

if nargin==0, help setrank; return; end

Sr = S;
Sr(r+1:end, r+1:end) = 0;





