% ma.m - MA modeling by Durbin's method
%
% Usage: [b,sigma2] = ma(y,q,M)
%
% y = complex-valued data signal (entered as row or column), y must have zero mean
% q = order of numerator filter B(z),   (q>0)
% M = order of preliminary AR filter    (M>>q)
%
% b = numerator filter, b = [1; b1; b2; ...; bq], by construction b0=1
% sigma2 = variance of input white noise
%
% notes: initial AR(M) model estimation can be done by any method, 
%        for example, using Burg, a = lpf(burg(y,M));
%
% algorithm:  a = lpf(yw(y,M));  fit an AR(M) model to y
%             A = datamat(a,q, 'aut'); A(1,:) = [];  construct A and delete its first row
%             b = lpls(A);  solve A*b = 0
%             or, equivalently, b = lpf(yw(a,q));  fit an AR(q) model to the filter a
%
% Reference:  J. Durbin, Efficient Estimation of Parameters of 
%             Moving-Average Models, Biometrika, vol.46, 306 (1959).

% S. J. Orfanidis - 2004
% ECE Department
% Rutgers University
% Piscataway, NJ 08854
% email: orfanidi@ece.rutgers.edu

function [b,sigma2] = ma(y,q,M)

if nargin==0, help ma; return; end

a = lpf(yw(y,M));                       % fit an AR(M) model to the data y
A = datamat(a,q,'aut'); A(1,:) = [];    % delete first row of A
b = lpls(A);                            % solve A*b = 0

sigma2 = std(y,1)^2 / norm(b)^2;        % use the "biased" version of std




