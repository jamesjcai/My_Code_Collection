This package contains the code for one example used in 
the IJCAI 2013 paper "Manifold Alignment Preserving Global Geometry".

A protein example:
The protein data is given in three .real files.

run 'protein.m' without any argument, you will see the alignment 
results of three proteins. You can look at the file and see how
to use the manifold alignment functions.


