
TF = TwoFactorsMutualInhibition(1000,100,1);
plot3(TF(:,1),TF(:,2),TF(:,3),'k.');