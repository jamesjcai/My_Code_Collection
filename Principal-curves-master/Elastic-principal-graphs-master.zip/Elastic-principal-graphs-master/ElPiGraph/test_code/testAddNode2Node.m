setallpaths;

tic
[NodePositionArray, ElasticMatrices] = GraphGrammarOperation(np,em,X,'addnode2node');
toc
