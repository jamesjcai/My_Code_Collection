function obj = f(x)
    
    x1 = x(1);
    x2 = x(2);
    obj = x1^2 - 2.0 * x1 * x2 + 4 * x2^2;